<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="utf-8">
    <title></title>
</head>
<body>
    <?php
    $i = 0;
        echo "1<br>";
        while($i < 3){
            echo "2<br>";
            $i++;
        }
        echo "3<br>";
    ?>
</body>
</html>
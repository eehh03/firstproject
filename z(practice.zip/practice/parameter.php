<!DOCTYPE html>
<html>
	<head>
	<meta charset="utf-8">
	</head>
	<body>
		안녕하세요. <?php echo $_GET['adrress'];?>에 사시는<?php echo $_GET['name']; ?>님
	</body>
</html>
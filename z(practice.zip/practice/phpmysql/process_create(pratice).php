<?php
    // // var_dump($_POST);
    // $conn = mysqli_connect('127.0.0.1','somej','sns5sms!','mydb');
    // if(mysqli_connect_errno()){
    //     echo "<script>alert('Mysql에 연결되지 않았습니다.')</script>";
    // }else{
    //     echo "<script>alert('연결에 성공하였습니다.')</script>";
    // }

    // $title = $_POST['title'];
    // $description = $_POST['description'];

    // $sql = "
    //         INSERT INTO topic(
    //             title,
    //             description,
    //             created)
    //             VALUE(
    //                 '$title',
    //                 '$description',
    //                 NOW()
    //             )        
    // ";
    // $result = mysqli_query($conn,$sql);
    // if($result == false){
    //     echo mysqli_error($conn);
    //     echo "<script>alert('저장하는데 문제가 생겼습니다, 다시 시도해주세요.')</script>";
    // }else{
    //     echo "<script>alert('저장에 성공했습니다.')</script>";
    //     $TRAP = false;
    //     if($TRAP == false){
    //         header('location:./index.php');    
    //     }
    // }
?>
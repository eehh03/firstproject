<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="utf-8">
</head>
<body>
    <h1>
        Comparison Operators & Boolean data type
    </h1>
    <?php
        echo '1<br>';
        echo '2<br>';
        echo '3<br>';
    ?>
    <h2>if</h2>
    <?php
        echo '1<br>';
        if(true){
            echo '2<br>';
        }
        echo '3<br>';
    ?>
</body>
</html>
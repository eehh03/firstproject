<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
</head>
<body>
    <h1>
        Comparison Operators & Boolean data type
    </h1>
    <?php
        var_dump('11');
        echo "<br>";
        var_dump(1+1);
        echo "<br>";
        var_dump(1==1);
    ?>
</body>
</html>
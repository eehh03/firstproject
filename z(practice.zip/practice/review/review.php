<?php
    require_once('lib/print.php');
    require_once('lib/header.php');
?>

    <!-- 내용 끝 -->
    <!-- create.php -->
    <button onclick="window.open('r_create.php','_self')">생성</button>
    <!-- create.php끝-->
<?php
    require_once('lib/footer.php');
?>